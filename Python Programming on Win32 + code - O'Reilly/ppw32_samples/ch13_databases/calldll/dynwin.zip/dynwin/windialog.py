# -*- Mode: Python; tab-width: 4 -*-

#from dyn_win32 import windll, winwin
import windll
import winwin

user32 = windll.module ('user32')

class dialog (winwin.window):

	def get_dlg_item (self, ident):
		hwnd = user32.GetDlgItem (self.hwnd, ident)
		if winwin.window_map.has_key (hwnd):
			# we know about this window
			return winwin.window_map[hwnd]
		else:
			return control (hwnd)

class control (winwin.window):
	pass

# ==================================================
#		dialog box functions
# ==================================================
# CreateDialog
# CreateDialogIndirect
# CreateDialogIndirectParam
# CreateDialogParam
# DefDlgProc
# DialogBox
# DialogBoxIndirect
# DialogBoxIndirectParam
# DialogBoxParam
# DialogProc
# EndDialog
# GetDialogBaseUnits
# GetDlgCtrlID
# GetDlgItem
# GetDlgItemInt
# GetDlgItemText
# GetNextDlgGroupItem
# GetNextDlgTabItem
# IsDialogMessage
# MapDialogRect
# MessageBox
# MessageBoxEx
# SendDlgItemMessage
# SetDlgItemInt
# SetDlgItemText
# MessageBoxIndirect 
