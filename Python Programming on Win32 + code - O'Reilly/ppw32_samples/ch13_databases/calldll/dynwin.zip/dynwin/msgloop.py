# -*- Mode: Python; tab-width: 4 -*-

#from dyn_win32 import structob, windll
import structob
import windll

user32 = windll.module ('user32')

class MSG (structob.struct_object):
	oracle = structob.Oracle (
		'windows message',
		'Nlllllll',
		('hwnd',
		 'message',
		 'wParam',
		 'lParam',
		 'time',
		 'x',
		 'y')
		)

msg = MSG()

# A message loop, all in Python!
def go():
	while user32.GetMessage (msg, 0, 0, 0):
		user32.TranslateMessage (msg)
		user32.DispatchMessage (msg)

# debugging version
stop_me = 0

def go():
	while not stop_me:
		if user32.GetMessage (msg, 0, 0, 0):
			user32.TranslateMessage (msg)
			user32.DispatchMessage (msg)
		else:
			break
