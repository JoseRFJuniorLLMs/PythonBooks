# -*- Mode: Python; tab-width: 4 -*-

import os
import win32con

def populate (db):
	num_unique_keys = 0
	num_constants	= 0
	for key in dir(win32con):
		if len(key) > 2 and key[:3] == 'WM_':
			num_constants = num_constants + 1
			# get the constant value as a string
			num = repr(getattr (win32con, key))
			if db.has_key (num):
				db[num].append (key)
			else:
				db[num] = [key]
				num_unique_keys = num_unique_keys + 1

db = {}	
	
populate(db)
