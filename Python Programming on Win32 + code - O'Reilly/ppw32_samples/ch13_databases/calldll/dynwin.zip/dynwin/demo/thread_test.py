# -*- Mode: Python; tab-width: 4 -*-

# This works, but not very well.  What is going on here?

import windll
import winwin
import msgloop
import thread

user32 = windll.module ('user32')

class my_edit (winwin.subclassed_window):
	def WM_MOUSEMOVE (self, wparam, lparam):
		pass
		#print 'mouse: %s: %08x %08x' % (repr(self), wparam, lparam)

main_id = thread.get_ident()

def make_window (detach=1):
	my_id = thread.get_ident()
		
	w = my_edit ('Thread #%d' % my_id, 'edit')
	w.create()
	w.show_window ()
	msgloop.go()

	global main_id

	if detach:
		user32.AttachThreadInput (main_id, my_id, 0)

if __name__ == '__main__':
	import sys
	if len(sys.argv) > 1:
		import string
		num = string.atoi (sys.argv[1]) - 1
	else:
		num = 3
	for n in range(num):
		thread.start_new_thread (make_window, (1,))

	make_window (0)
