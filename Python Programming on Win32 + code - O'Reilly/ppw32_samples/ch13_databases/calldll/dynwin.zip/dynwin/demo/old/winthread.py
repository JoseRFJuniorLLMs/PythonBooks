# -*- Mode: Python; tab-width: 4 -*-

# This does not work with thread support compiled in.
# Probably won't work anyway!

import windll
import gencb

kernel32 = windll.module ('kernel32')

def create_thread (thunk):
	cb = gencb.callback ("l", thunk)
	id = windll.membuf (4)
	return kernel32.CreateThread (
		0,	# no security attributes
		0,	# default stack size
		cb,	# ThreadFunc
		0,	# no argument
		0,	# default creation flags
		id
		)
