
'''this module indicates where the sql datastructures are marshalled
   Auto generated on install: better not touch!
'''

filename = 'D:\\downloads\\kwParsing\\sql.mar'
